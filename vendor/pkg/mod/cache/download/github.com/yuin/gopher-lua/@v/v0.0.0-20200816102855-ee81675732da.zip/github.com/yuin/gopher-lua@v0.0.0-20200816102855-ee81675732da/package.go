// GopherLua: VM and compiler for Lua in Go
package lua

const PackageName = "GopherLua"
const PackageVersion = "0.1"
const PackageAuthors = "Yusuke Inuzuka"
const PackageCopyRight = PackageName + " " + PackageVersion + " Copyright (C) 2015 -2017 " + PackageAuthors
